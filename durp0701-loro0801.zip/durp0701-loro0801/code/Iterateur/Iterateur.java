package Iterateur;

/**
 * Intrerface pour créer des itérateurs
 */
public interface Iterateur {

    public Object next();
    public boolean isFinished();
}
